var gulp = require('gulp');
var postcss = require('gulp-postcss');

var browserSync = require('browser-sync').create();

var autoprefixer = require('autoprefixer');
var ant = require('postcss-ant');

var sass = require('gulp-sass');

gulp.task('css', function () {
	var processors = [
        ant,
		autoprefixer
	];
  return gulp.src('./src/style.css')
    .pipe(postcss(processors))
    .pipe(gulp.dest('./css'));
});

gulp.task('sass', function () {
  return gulp.src('./src/style.scss')
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest('./src'));
});

gulp.task('sass-watch', ['sass'], function (done) {
    done();
});

gulp.task('css-watch', ['css'], function (done) {
    browserSync.reload();
    done();
});

gulp.task('serve', ['css-watch'], function () {

    browserSync.init({
        server: {
            baseDir: "./"
        }
    });

    // Uncomment the line below if you want to use Sass
    // gulp.watch('./src/style.scss', ['sass-watch']);
    gulp.watch('./src/style.css', ['css-watch']);
});